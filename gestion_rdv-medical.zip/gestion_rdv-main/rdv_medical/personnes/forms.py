from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm
from bootstrap_datepicker_plus.widgets import DatePickerInput
from personnes.models import *
from metiers.models import *

from bootstrap_datepicker_plus.widgets import DatePickerInput

class InscriptionPatientForm(UserCreationForm):

    def __init__(self, *args, **kwargs):
        super(InscriptionPatientForm, self).__init__(*args, **kwargs)
        self.fields['gender'].required = True
        self.fields['first_name'].label = ""
        self.fields['last_name'].label = ""
        self.fields['naissance'].label = ""
        self.fields['email'].label = ""
        self.fields['phone_number'].label = ""
        self.fields['adresse'].label = ""
        self.fields['password1'].label = ""
        self.fields['password2'].label = ""
        for fieldname in ['password1', 'password2']:
            self.fields[fieldname].help_text = None

        self.fields['gender'].widget.attrs.update(
            {
                'placeholder': 'Civile',
            }
        )
        self.fields['first_name'].widget.attrs.update(
            {
                'placeholder': 'Nom',
            }
        )
        self.fields['last_name'].widget.attrs.update(
            {
                'placeholder': 'Prenom',
            }
        )
       

        self.fields['email'].widget.attrs.update(
            {
                'placeholder': 'Email',
            }
        )
        self.fields['phone_number'].widget.attrs.update(
            {
                'placeholder': 'Numéro',
            }
        )
        self.fields['adresse'].widget.attrs.update(
            {
                'placeholder': 'Adresse',
            }
        )
        self.fields['password1'].widget.attrs.update(
            {
                'placeholder': 'Password',
            }
        )
        self.fields['password2'].widget.attrs.update(
            {
                'placeholder': 'Confirm Password',
            }
        )

        self.fields["naissance"].widget = DatePickerInput()
        self.fields['naissance'].widget.attrs.update(
            {
                'placeholder': 'Date de naissance',
            }
        )
    class Meta:
        model = Patient

        fields = ['gender', 'first_name', 'last_name', 'naissance', 'email', 'phone_number', 'adresse', 'password1', 'password2' ]
        error_messages = {
            'first_name': {
                'required': 'First name is required',
                'max_length': 'Name is too long'
            },
            'last_name': {
                'required': 'Last name is required',
                'max_length': 'Last Name is too long'
            },
            'gender': {
                'required': 'Gender is required'
            }
        }


    def clean_gender(self):
        gender = self.cleaned_data.get('gender')
        if not gender:
            raise forms.ValidationError("Gender is required")
        return gender

    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.role = "patient"
        if commit:
            user.save()
        return user


class InscriptionDocteurForm(UserCreationForm):

    def __init__(self, *args, **kwargs):
        super(InscriptionDocteurForm, self).__init__(*args, **kwargs)
        self.fields['gender'].required = True
        self.fields['first_name'].label = ""
        self.fields['last_name'].label = ""
        self.fields['naissance'].label = ""
        self.fields['email'].label = ""
        self.fields['service'].label = ""
        self.fields['specialite'].label = ""
        self.fields['adresse'].label = ""
        self.fields['phone_number'].label = ""
        self.fields['password1'].label = ""
        self.fields['password2'].label = ""
        for fieldname in ['password1', 'password2']:
            self.fields[fieldname].help_text = None
        
        self.fields['gender'].widget.attrs.update(
            {
                'placeholder': 'Civile',
            }
        )
        self.fields['first_name'].widget.attrs.update(
            {
                'placeholder': 'Nom',
            }
        )
        self.fields['last_name'].widget.attrs.update(
            {
                'placeholder': 'Prenom',
            }
        )
        self.fields['email'].widget.attrs.update(
            {
                'placeholder': 'Email',
            }
        ) 
        self.fields['service'].widget.attrs.update(
            {
                'placeholder': 'Service',
            }
        )
        self.fields['specialite'].widget.attrs.update(
            {
                'placeholder': 'Specialite',
            }
        )
        self.fields['phone_number'].widget.attrs.update(
            {
                'placeholder': 'Numéro',
            }
        )
        self.fields['adresse'].widget.attrs.update(
            {
                'placeholder': 'Adresse',
            }
        )
        self.fields['password1'].widget.attrs.update(
            {
                'placeholder': 'Password',
            }
        )
        self.fields['password2'].widget.attrs.update(
            {
                'placeholder': 'Confirm Password',
            }
        )
        self.fields["naissance"].widget = DatePickerInput()
        self.fields['naissance'].widget.attrs.update(
            {
                'placeholder': 'Date de naissance',
            }
        )

    class Meta:
        model = Docteur
        fields = ['gender', 'first_name', 'last_name', 'naissance', 'email', 'service', 'specialite', 'phone_number', 'adresse', 'password1', 'password2' ]
        error_messages = {
            'first_name': {
                'required': 'First name is required',
                'max_length': ' First Name is too long'
            },
            'last_name': {
                'required': 'Last name is required',
                'max_length': 'Last Name is too long'
            }
        }

    def clean_gender(self):
        gender = self.cleaned_data.get('gender')
        if not gender:
            raise forms.ValidationError("Gender is required")
        return gender

    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.role = "doctor"
        if commit:
            user.save()
        return user


class InscriptionSecretaireForm(UserCreationForm):

    def __init__(self, *args, **kwargs):
        super(InscriptionSecretaireForm, self).__init__(*args, **kwargs)
        self.fields['gender'].required = True
        self.fields['first_name'].label = ""
        self.fields['last_name'].label = ""
        self.fields['naissance'].label = ""
        self.fields['email'].label = ""
        self.fields['phone_number'].label = ""
        self.fields['adresse'].label = ""
        self.fields['password1'].label = ""
        self.fields['password2'].label = ""
        for fieldname in ['password1', 'password2']:
            self.fields[fieldname].help_text = None

        self.fields['first_name'].widget.attrs.update(
            {
                'placeholder': 'Nom',
            }
        )
        self.fields['last_name'].widget.attrs.update(
            {
                'placeholder': 'Prenom',
            }
        )
        self.fields['email'].widget.attrs.update(
            {
                'placeholder': 'Email',
            }
        )
        self.fields['phone_number'].widget.attrs.update(
            {
                'placeholder': 'Numéro',
            }
        )
        self.fields['adresse'].widget.attrs.update(
            {
                'placeholder': 'Adresse',
            }
        )
        self.fields['phone_number'].widget.attrs.update(
            {
                'placeholder': 'Numéro',
            }
        )
        self.fields['password1'].widget.attrs.update(
            {
                'placeholder': 'Password',
            }
        )
        self.fields['password2'].widget.attrs.update(
            {
                'placeholder': 'Confirm Password',
            }
        )
        self.fields["naissance"].widget = DatePickerInput()
        self.fields['naissance'].widget.attrs.update(
            {
                'placeholder': 'Date de naissance',
            }
        )

    class Meta:
        model = Secretaire

        fields = ['gender', 'first_name', 'last_name', 'naissance', 'email', 'phone_number', 'adresse', 'password1', 'password2' ]
        error_messages = {
            'first_name': {
                'required': 'First name is required',
                'max_length': 'Name is too long'
            },
            'last_name': {
                'required': 'Last name is required',
                'max_length': 'Last Name is too long'
            },
            'gender': {
                'required': 'Gender is required'
            }
        }

    def clean_gender(self):
        gender = self.cleaned_data.get('gender')
        if not gender:
            raise forms.ValidationError("Gender is required")
        return gender

    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.role = "secretaire"
        if commit:
            user.save()
        return user


class UserLoginForm(forms.Form):
    email = forms.EmailField(
      label="",  
    )
    password = forms.CharField(
        label="",
        strip=False,
        widget=forms.PasswordInput,
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = None
        self.fields['email'].widget.attrs.update({'placeholder': 'Email adresse'})
        self.fields['password'].widget.attrs.update({'placeholder': 'Password'})

    def clean(self, *args, **kwargs):
        email = self.cleaned_data.get("email")
        password = self.cleaned_data.get("password")

        if email and password:
            self.user = authenticate(email=email, password=password)
            if self.user is None:
                raise forms.ValidationError("User Does Not Exist.")
            if not self.user.check_password(password):
                raise forms.ValidationError("Password Does not Match.")
            if not self.user.is_active:
                raise forms.ValidationError("User is not Active.")
        return super(UserLoginForm, self).clean(*args, **kwargs)

    def get_user(self):
        return self.user

class PatientProfileUpdateForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(PatientProfileUpdateForm, self).__init__(*args, **kwargs)

    class Meta:
        model = Patient
        fields = ['gender', 'first_name', 'last_name', 'naissance', 'email', 'phone_number', 'adresse' ]

class SecretaireProfileUpdateForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(SecretaireProfileUpdateForm, self).__init__(*args, **kwargs)


    class Meta:
        model = Secretaire
        fields = ['gender', 'first_name', 'last_name', 'naissance', 'email', 'phone_number', 'adresse' ]

class DoctorProfileUpdateForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(DoctorProfileUpdateForm, self).__init__(*args, **kwargs)

    class Meta:
        model = Docteur
        fields = ['gender', 'first_name', 'last_name', 'naissance', 'email', 'service', 'specialite', 'phone_number', 'adresse']


