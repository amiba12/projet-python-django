from secrets import choice
from django.contrib.auth.models import AbstractUser
from django.db import models
from datetime import date
from personnes.managers import UserManager

GENDER_CHOICES = (
    ('male', 'M'),
    ('female', 'Mme '))
SERVICES = (
    ('cardiologie', "Cardiologie"),
    ('Odontologie', "Odontologie"),
    ('Neurologie', "Neurologie"),
    ('Dermatologie', 'Dermatologie'),
    ('Gynécologie', 'Gynécologie'),
    ('Depistage sanguin', 'Depistage sanguin'),
    ('Ophtalmologie', 'Ophtalmologie'),
    ('Thérapie phusique', 'Thérapie phusique'),
)

class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True, blank=False,
                            error_messages={
                                'unique': "A user with that email already exists.",
                            })
    role = models.CharField(max_length=12, error_messages={
        'required': "Role must be provided"
    })
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []


    def __str__(self):
        return f"{self.last_name} {self.first_name}"

class Patient(User):

    gender = models.CharField(max_length=10, blank=True, null=True, choices=GENDER_CHOICES)

    naissance = models.DateField(blank=True, null=True, default=date.today().strftime("%Y-%m-%d"))
    phone_number = models.CharField(unique=True, blank=True, null=True, max_length=20,
                                    error_messages={
                                        'unique': "A user with that phone number already exists."
                                    })
    adresse = models.CharField(max_length=200, blank=False, null=True, default="")



    objects = UserManager()

class Secretaire(User):
    username = None

    gender = models.CharField(max_length=10, blank=True, null=True, choices=GENDER_CHOICES)

    naissance = models.DateField(blank=True, null=True, default=date.today().strftime("%Y-%m-%d"))
    phone_number = models.CharField(unique=True, blank=True, null=True, max_length=20,
                                    error_messages={
                                        'unique': "A user with that phone number already exists."
                                    })
    adresse = models.CharField(max_length=200, blank=False, null=True, default="")



    objects = UserManager()

class Docteur(User):

    gender = models.CharField(max_length=10, blank=True, null=True, choices=GENDER_CHOICES)

    naissance = models.DateField(blank=True, null=True, default=date.today().strftime("%Y-%m-%d"))
    phone_number = models.CharField(unique=True, blank=True, null=True, max_length=20,
                                    error_messages={
                                        'unique': "A user with that phone number already exists."
                                    })
    adresse = models.CharField(max_length=200, blank=False, null=True, default="")
    specialite = models.CharField(max_length=200, blank=False, null=True, default="")
    service = models.CharField(max_length=200, blank=False, null=True, choices=SERVICES)



    objects = UserManager()