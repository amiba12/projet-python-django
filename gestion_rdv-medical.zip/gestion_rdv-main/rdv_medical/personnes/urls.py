from django.urls import path

from .views import *
from metiers.views import *

app_name = 'personnes'

urlpatterns = [

    path('patient/inscription', InscriptionPatient.as_view(), name='patient-inscription'),
    path('patient/profile/update/', EditPatientProfile.as_view(), name='patient-profile-update'),
    path('docteur/inscription', InscriptionDoctor.as_view(), name='doctor-inscription'),
    path('secretaire/inscription', InscriptionSecretaire.as_view(), name='secretaire-inscription'),
    path('secretaire/profile/update', EditeSecretaireView.as_view(), name='secretaire-profile-update'),
    path('doctor/profile/update/', EditDoctorProfileView.as_view(), name='doctor-profile-update'),
    path('login', LoginView.as_view(), name='login'),
    path('logout', LogoutView.as_view(), name='logout'),
]