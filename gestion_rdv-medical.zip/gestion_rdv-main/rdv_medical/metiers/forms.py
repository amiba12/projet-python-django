from django import forms
from .models import *
from bootstrap_datepicker_plus.widgets import DatePickerInput, TimePickerInput

# Patient

class PrendreRdvPatientForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(PrendreRdvPatientForm, self).__init__(*args, **kwargs)
        self.fields['date'].label = ""
        self.fields['debut'].label = ""
        self.fields['fin'].label = ""
        self.fields['motif'].label = ""
        self.fields['patient'].label=""
        self.fields['adresse'].label=""
        self.fields['patient'].widget.attrs.update(
            {
                'placeholder': 'Nom Prenom',
            }
        ) 
        self.fields["date"].widget = DatePickerInput()
        self.fields['date'].widget.attrs.update(
            {
                'placeholder': 'Date',
            }
        )
        self.fields["debut"].widget = TimePickerInput()
        self.fields['debut'].widget.attrs.update(
            {
                'placeholder': 'Heure de Début',
            }
        )
        self.fields["fin"].widget = TimePickerInput()
        self.fields['fin'].widget.attrs.update(
            {
                'placeholder': 'Heure de Fin',
            }
        )
        self.fields['adresse'].widget.attrs.update(
            {
                'placeholder': 'Adresse',
            }
        )
        self.fields['motif'].widget.attrs.update(
            {
                'placeholder': 'Motif',
            }
        )
  
    class Meta:
        model = RendezVous
        fields = ['patient','docteurs', 'date', 'debut', 'fin', 'adresse','motif']

    def is_valid(self):
        valid = super(PrendreRdvPatientForm, self).is_valid()

        # if already valid, then return True
        if valid:
            return valid
        return valid

    def save(self, commit=True):
        appointment = super(PrendreRdvPatientForm, self).save(commit=False)
        if commit:
            appointment.save()
        return appointment

class PatientRdvUpdateForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(PatientRdvUpdateForm, self).__init__(*args, **kwargs)
        self.fields["date"].widget = DatePickerInput()
        self.fields["debut"].widget = TimePickerInput()
        self.fields["fin"].widget = TimePickerInput()

    class Meta:
        model = RendezVous
        fields = ['patient', 'docteurs','date', 'debut', 'adresse', 'fin', 'motif']





# Secretaire

class SecretaireRdvPatientForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(SecretaireRdvPatientForm, self).__init__(*args, **kwargs)
        self.fields['date'].label = ""
        self.fields['debut'].label = ""
        self.fields['fin'].label = ""
        self.fields['motif'].label = ""
        self.fields['patient'].label=""
        self.fields['adresse'].label=""
        self.fields['patient'].widget.attrs.update(
            {
                'placeholder': 'Nom Prenom',
            }
        ) 
        self.fields["date"].widget = DatePickerInput()
        self.fields['date'].widget.attrs.update(
            {
                'placeholder': 'Date',
            }
        )
        self.fields["debut"].widget = TimePickerInput()
        self.fields['debut'].widget.attrs.update(
            {
                'placeholder': 'Heure de Début',
            }
        )
        self.fields["fin"].widget = TimePickerInput()
        self.fields['fin'].widget.attrs.update(
            {
                'placeholder': 'Heure de Fin',
            }
        )
        self.fields['adresse'].widget.attrs.update(
            {
                'placeholder': 'Adresse',
            }
        )
        self.fields['motif'].widget.attrs.update(
            {
                'placeholder': 'Motif',
            }
        )
  
    class Meta:
        model = RendezVous
        fields = ['patient','docteurs', 'date', 'debut', 'fin', 'adresse','motif']

    def is_valid(self):
        valid = super(SecretaireRdvPatientForm, self).is_valid()

        # if already valid, then return True
        if valid:
            return valid
        return valid

    def save(self, commit=True):
        appointment = super(SecretaireRdvPatientForm, self).save(commit=False)
        if commit:
            appointment.save()
        return appointment

class SecretaireRdvUpdateForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(SecretaireRdvUpdateForm, self).__init__(*args, **kwargs)
        self.fields["date"].widget = DatePickerInput()
        self.fields["debut"].widget = TimePickerInput()
        self.fields["fin"].widget = TimePickerInput()
         
    class Meta:
        model = RendezVous
        fields = ['patient','docteurs', 'date', 'debut', 'fin', 'adresse','motif']


# Docteur

class DossierCreateViewForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(DossierCreateViewForm, self).__init__(*args, **kwargs)
        self.fields['patient'].label = ""
        self.fields['antecedant'].label = ""
        self.fields['allergie'].label = ""
        self.fields['medicament_actuel'].label = ""
        
        self.fields['patient'].widget.attrs.update(
            {
                'placeholder': 'Nom Prenom',
            }
        ) 
        self.fields['antecedant'].widget.attrs.update(
            {
                'placeholder': 'Antecedants',
            }
        )
        self.fields['allergie'].widget.attrs.update(
            {
                'placeholder': 'Allergies',
            }
        )
        self.fields['medicament_actuel'].widget.attrs.update(
            {
                'placeholder': 'Medicament Acuel',
            }
        )

  
    class Meta:
        model = DossierPatient
        fields = ['patient','antecedant', 'allergie', 'medicament_actuel']

    def is_valid(self):
        valid = super(DossierCreateViewForm, self).is_valid()

        # if already valid, then return True
        if valid:
            return valid
        return valid

    def save(self, commit=True):
        appointment = super(DossierCreateViewForm, self).save(commit=False)
        if commit:
            appointment.save()
        return appointment
class EditDossierPatientForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(EditDossierPatientForm, self).__init__(*args, **kwargs)

         
    class Meta:
        model = DossierPatient
        fields = ['patient','antecedant', 'allergie', 'medicament_actuel']



class AgendaCreateViewForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(AgendaCreateViewForm, self).__init__(*args, **kwargs)
        self.fields['docteur'].label = ""
        self.fields['date'].label = ""
        self.fields['start_time'].label = ""
        self.fields['end_time'].label = ""
        self.fields['hospital_name'].label = ""
        self.fields['adresse'].label = ""


        self.fields['docteur'].widget.attrs.update(
            {
                'placeholder': 'Docteur',
            }
        )

        self.fields["date"].widget = DatePickerInput()       
        self.fields["start_time"].widget = TimePickerInput()
        self.fields["end_time"].widget = TimePickerInput()
        self.fields['hospital_name'].widget.attrs.update(
            {
                'placeholder': 'Nom Hopital',
            }
        )
        self.fields['adresse'].widget.attrs.update(
            {
                'placeholder': 'Adresse',
            }
        )

  
    class Meta:
        model = Agenda
        fields = ['docteur','date', 'start_time', 'end_time', 'hospital_name', 'adresse' ]

    def is_valid(self):
        valid = super(AgendaCreateViewForm, self).is_valid()

        # if already valid, then return True
        if valid:
            return valid
        return valid

    def save(self, commit=True):
        appointment = super(AgendaCreateViewForm, self).save(commit=False)
        if commit:
            appointment.save()
        return appointment

