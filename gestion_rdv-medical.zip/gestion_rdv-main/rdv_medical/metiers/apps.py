from django.apps import AppConfig


class MetiersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'metiers'
