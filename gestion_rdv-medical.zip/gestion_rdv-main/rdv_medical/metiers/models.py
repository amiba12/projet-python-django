import datetime
from multiprocessing.sharedctypes import Value
from django.db import models
from datetime import datetime
from personnes.models import *

DISPONIBILITE_CHOICES = (
    ('dispo', 'disponible'),
    ('indispo', 'indisponible '))

class Agenda(models.Model):
    docteur = models.ForeignKey(Docteur, on_delete=models.CASCADE, null=True)
    image = models.ImageField(null=True, blank=True)
    date = models.DateField(blank=True, null=True, default=datetime.today().strftime("%Y-%m-%d"))
    start_time = models.CharField(max_length=10)
    end_time = models.CharField(max_length=10)
    hospital_name = models.CharField(max_length=100)
    adresse = models.CharField(max_length=100)
    disponibilite = models.CharField(max_length=10, blank=True, null=True, choices=DISPONIBILITE_CHOICES)

    
    def __str__(self):
        return f"{self.docteur.last_name} {self.docteur.first_name}"




class RendezVous(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    docteurs = models.ForeignKey(Agenda, on_delete=models.CASCADE)
    date = models.DateField(blank=True, null=True, default=datetime.today().strftime("%Y-%m-%d"))
    debut = models.TimeField(null=True, blank=True)
    fin = models.TimeField(null=True, blank=True)
    adresse = models.CharField(max_length=100)
    motif = models.TextField()




class DossierPatient(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    antecedant = models.TextField()
    allergie = models.TextField()
    medicament_actuel = models.TextField()

