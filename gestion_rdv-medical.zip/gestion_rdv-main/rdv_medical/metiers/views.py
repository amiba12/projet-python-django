from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from personnes.models import *
from .decorators import user_is_patient, user_is_doctor, user_is_secretaire
from django.views.generic import  UpdateView, CreateView, ListView, DeleteView, TemplateView
from django.views.generic.edit import DeleteView, UpdateView
from personnes.forms import *
from .forms import *
from .models import *



class EditPatientProfile(UpdateView):
    model = Patient
    form_class = PatientProfileUpdateForm
    context_object_name = 'patient'
    template_name = 'personnes/patients/edit-profile.html'
    success_url = reverse_lazy('personnes:patient-profile-update')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    @method_decorator(user_is_patient)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(self.request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        try:
            self.object = self.get_object()
        except Http404:
            raise Http404("User doesn't exists")
        # context = self.get_context_data(object=self.object)
        return self.render_to_response(self.get_context_data())

    def get_object(self, queryset=None):
        obj = self.request.user
        print(obj)
        if obj is None:
            raise Http404("Patient doesn't exists")
        return obj


class EditeSecretaireView(UpdateView):
    model = Secretaire
    form_class = SecretaireProfileUpdateForm
    context_object_name = 'secretaire'
    template_name = 'personnes/secretaires/edit-profile.html'
    success_url = reverse_lazy('personnes:secretaire-profile-update')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    @method_decorator(user_is_secretaire)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(self.request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        try:
            self.object = self.get_object()
        except Http404:
            raise Http404("User doesn't exists")
        # context = self.get_context_data(object=self.object)
        return self.render_to_response(self.get_context_data())

    def get_object(self, queryset=None):
        obj = self.request.user
        print(obj)
        if obj is None:
            raise Http404("Patient doesn't exists")
        return obj


class EditDoctorProfileView(UpdateView):
    model = Docteur
    form_class = DoctorProfileUpdateForm
    context_object_name = 'doctor'
    template_name = 'personnes/docteurs/edit-profile.html'
    success_url = reverse_lazy('personnes:doctor-profile-update')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    @method_decorator(user_is_doctor)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(self.request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        try:
            self.object = self.get_object()
        except Http404:
            raise Http404("User doesn't exists")
        # context = self.get_context_data(object=self.object)
        return self.render_to_response(self.get_context_data())

    def get_object(self, queryset=None):
        obj = self.request.user
        if obj is None:
            raise Http404("Patient doesn't exists")
        return obj




class IndexPage(TemplateView):

    template_name = "index.html"



class HomePage(ListView):
    paginate_by = 9
    model = Agenda
    context_object_name = 'agenda'
    template_name = "home.html"

    def get_queryset(self):
        return self.model.objects.all().order_by('-id')


class ConsulterRdv(ListView):
    model = RendezVous
    context_object_name = 'rdv'
    template_name = "metiers/consulter_rdv.html"

    def get_queryset(self):
        return self.model.objects.filter(patient_id=self.request.user.id).order_by('-id')

class ConsulterRdvDocteur(ListView):
    model = RendezVous
    context_object_name = 'rdv'
    template_name = "metiers/d_consulter_rdv.html"

    def get_queryset(self):
        return self.model.objects.filter().order_by('-id')

class Service(TemplateView):
    template_name = 'metiers/services.html'




#  Rdv Secretaire

class PrendreRdvSecretaire(CreateView):
    template_name = 'metiers/s_prendre_rdv.html'
    form_class = SecretaireRdvPatientForm
    extra_context = {
        'title': 'Prendre Rdv'
    }
    success_url = reverse_lazy('metiers:secretaire-consulter-rdv')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    def dispatch(self, request, *args, **kwargs):

        if not self.request.user.is_authenticated:
            return reverse_lazy('personnes:login')
        if self.request.user.is_authenticated and self.request.user.role != 'secretaire':
            return reverse_lazy('personnes:login')
        return super().dispatch(self.request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(PrendreRdvSecretaire, self).form_valid(form)

    def post(self, request, *args, **kwargs):
        self.object = None

        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)

class EditRdvSecretaire(UpdateView):
    model = RendezVous
    form_class = SecretaireRdvUpdateForm
    context_object_name = 'secretaire'
    template_name = 'metiers/s_modifier_rdv.html'
    success_url = reverse_lazy('metiers:secretaire-consulter-rdv')

class DeleteRdvSecretaire(DeleteView):
    model = RendezVous
    success_url = reverse_lazy('metiers:secretaire-consulter-rdv')

class ConsulterRdvSecretaire(ListView):
    model = RendezVous
    context_object_name = 'rdv'
    template_name = "metiers/s_consulter_rdv.html"

    def get_queryset(self):
        return self.model.objects.filter().order_by('-id')



# Rdv Patient

class PrendreRdvPatient(CreateView):
    template_name = 'metiers/prendre_rdv.html'
    form_class = PrendreRdvPatientForm
    extra_context = {
        'title': 'Prendre Rdv'
    }
    success_url = reverse_lazy('metiers:consulter-rdv')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    def dispatch(self, request, *args, **kwargs):

        if not self.request.user.is_authenticated:
            return reverse_lazy('personnes:login')
        if self.request.user.is_authenticated and self.request.user.role != 'patient':
            return reverse_lazy('personnes:login')
        return super().dispatch(self.request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(PrendreRdvPatient, self).form_valid(form)

    def post(self, request, *args, **kwargs):
        self.object = None

        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)

class ConsulterRdvPatient(ListView):
    model = RendezVous
    context_object_name = 'rdv'
    template_name = "metiers/p_consulter_rdv.html"

    def get_queryset(self):
        return self.model.objects.filter(patient_id=self.request.user.id).order_by('-id')

class EditRdvPatient(UpdateView):
    model = RendezVous
    form_class = PatientRdvUpdateForm
    context_object_name = 'patient'
    template_name = 'metiers/p_modifier_rdv.html'
    success_url = reverse_lazy('metiers:consulter-rdv')


  
            
    
class CreerAgenda(CreateView):
    template_name = 'metiers/docteur_agenda.html'
    form_class = AgendaCreateViewForm
    extra_context = {
        'title': 'New Dossier Patient'
    }
    success_url = reverse_lazy('metiers:docteur-creer-agenda')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    def dispatch(self, request, *args, **kwargs):
        if not self.request.user.is_authenticated:
            return reverse_lazy('personnes:login')
        if self.request.user.is_authenticated and self.request.user.role != 'doctor':
            return reverse_lazy('personnes:login')
        return super().dispatch(self.request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(CreerAgenda, self).form_valid(form)

    def post(self, request, *args, **kwargs):
        self.object = None
        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)


# Dossier Patient

class CreerDossier(CreateView):
    template_name = 'metiers/creer_dossier.html'
    form_class = DossierCreateViewForm
    extra_context = {
        'title': 'New Dossier Patient'
    }
    success_url = reverse_lazy('metiers:docteur-consulter-dossier')

    @method_decorator(login_required(login_url=reverse_lazy('personnes:login')))
    def dispatch(self, request, *args, **kwargs):
        if not self.request.user.is_authenticated:
            return reverse_lazy('personnes:login')
        if self.request.user.is_authenticated and self.request.user.role != 'doctor':
            return reverse_lazy('personnes:login')
        return super().dispatch(self.request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super(CreerDossier, self).form_valid(form)

    def post(self, request, *args, **kwargs):
        self.object = None
        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)

class EditDossier(UpdateView):
    model = DossierPatient
    form_class = EditDossierPatientForm
    context_object_name = 'dossier_patient'
    template_name = 'metiers/s_modifier_rdv.html'
    success_url = reverse_lazy('metiers:docteur-consulter-dossier')

class ConsulterDossier(ListView):
    model = DossierPatient
    context_object_name = 'dossier'
    template_name = "metiers/dossier_patient.html"

    def get_queryset(self):
        return self.model.objects.filter().order_by('-id')

class DeleteDossier(DeleteView):
    model = DossierPatient
    success_url = reverse_lazy('metiers:docteur-consulter-dossier')
