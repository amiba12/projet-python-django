
from django.urls import path
from metiers.views import *
from django.conf import settings
from django.conf.urls.static import static


app_name = 'metiers'

urlpatterns = [
    path('', IndexPage.as_view(), name='index'),
    path('home', HomePage.as_view(), name='home'),
    path('service', Service.as_view(), name='service'),
    path('docteur/agenda/', CreerAgenda.as_view(), name='docteur-creer-agenda'),
    path('docteur/creer_dossier/', CreerDossier.as_view(), name='docteur-creer-dossier'),
    path('docteur/consulter_dossier/', ConsulterDossier.as_view(), name='docteur-consulter-dossier'),
    path('docteur/modifier_dossier/<pk>', EditDossier.as_view(), name='docteur-modifier-dossier'),
    path('doctor/supprimer_dossier/<pk>', DeleteDossier.as_view(), name='docteur-supprimer-dossier'),
    path('docteur/consulter_rdv/<pk>', ConsulterRdvDocteur.as_view(), name='docteur-consulter-rdv'),
    path('patient/prendre_rdv/', PrendreRdvPatient.as_view(), name='patient-prendre-rdv'),
    path('patient/consulter_rdv/<pk>', ConsulterRdvPatient.as_view(), name='patient-consulter-rdv'),
    path('patient/modifier_rdv/<pk>', EditRdvPatient.as_view(), name='patient-modifier-rdv'),
    path('secretaire/prendre_rdv/', PrendreRdvSecretaire.as_view(), name='secretaire-prendre-rdv'),
    path('secretaire/modifier_rdv/<pk>', EditRdvSecretaire.as_view(), name='secretaire-modifier-rdv'),
    path('secretaire/supprimer_rdv/<pk>', DeleteRdvSecretaire.as_view(), name='secretaire-supprimer-rdv'),
    path('secretaire/consulter_rdv/', ConsulterRdvSecretaire.as_view(), name='secretaire-consulter-rdv'),
    path('consulter_rdv', ConsulterRdv.as_view(), name='consulter-rdv'),

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)