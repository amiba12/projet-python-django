# gestion_rdv

## Avand de lancer de projet

*   Pour lancer le projet il faut installer le contenu du fichier requirement.txt

## Ensuite lancer les commandes:

* python manage.py makemigrations  personnes
* python manage.py makemigrations  metiers
* python manage.py migrate
* python manage.py runserver 0.0.0.0:8000